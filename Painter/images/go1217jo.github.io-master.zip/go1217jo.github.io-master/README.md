# go1217jo.github.io
<h1>web publishing storage</h1>

<h2>I save all web project in this repository.</h2>

1. go1217jo.github.io/ironman/index.html : ironman introduction webpage

2. go1217jo.github.io/omok/omok.html : omok game using javascript (ongoing, start : October 24, 2017 tuesday)
